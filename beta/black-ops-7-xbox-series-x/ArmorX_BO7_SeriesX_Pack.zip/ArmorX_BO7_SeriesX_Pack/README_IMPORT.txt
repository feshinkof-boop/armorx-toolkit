ArmorX Pro - Black Ops 7 / Xbox Series X Pack

RECOMMENDED START:
  profiles/BO7_Competitive_Recommended.json

IMPORT PROFILE:
  ArmorX Studio v0.6.0 -> Profiles -> Import -> select JSON -> Load -> Review & Apply.
  The app will compare the profile to the live device and merge only known editable fields.

MACROS:
  ArmorX Studio v0.6.0 -> Macro Studio -> Import -> select a macro JSON.
  IMPORTANT: v0.6.0 Macro Studio is offline-only. It can import/edit/export these files, but does not install macros to the ArmorX hardware yet.

BASELINE SAFETY:
  Profiles were built from the exact validated ZJ-XT firmware 2741 baseline:
  SHA-256 bdef9c619dba4836c89073df6e63860a21ad26a1c0b92946ae68fb68a895beb6
  CRC 0x2C40
  Only M1-M4 mapping bytes were intentionally changed; trigger/stick/gyro/turbo bytes remain the validated baseline.

IN-GAME SETTINGS:
  See BO7_in_game_settings.json. Sensitivity, ADS multiplier, FOV and BO7 deadzones are game settings and cannot be encoded in an ArmorX 144-byte profile.

MACRO TIMING:
  YY Normal is the default candidate. Fast/Safe variants are included because minimum reliable registration can vary.
  Slide Jump includes 75/85/95 ms variants for controlled testing.

NOTE:
  Automated inputs can be restricted by game rules/anti-cheat. Use macros only where permitted.
